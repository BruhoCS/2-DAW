Funcionalidad nos apartados 
“Entrenos”→ permite contruir unha rutina mediante un formulario
“Tienda”→permite seleccionar productos y añadilos ao carrito dando o prezo total
“Administracion”→no casi de que o usuarios sexa administrador permite engadir e borrar usuarios
