import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { UsuariosService } from '../../usuarios.service';
import { Usuario } from '../modelo/usuario';

@Component({
  selector: 'app-administracion',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './administracion.component.html',
  styleUrl: './administracion.component.css'
})

export class AdministracionComponent implements OnInit {
  formulario: FormGroup;//Definimos el formulario que irá asociado al formulario
  usuarios: Usuario[];//Array que gardará os usuarios almacenados na sessionStorage
  //Declaremos la propiedad FormBuilder que agilizará la creación del formulario
  constructor(private elaborador: FormBuilder, private router: Router, private servicioUsuario: UsuariosService) {
    this.formulario = this.elaborador.group({
      //Definimos los arrays para cada control del formulario
      nombre: ["", [Validators.required]],
      rol: ["", [Validators.required]],
      contrasenha: ["", [Validators.required]]
    });
  }

  //Funcion para guardar la sesión
  crearUsuario(evento: Event) {
    evento.preventDefault();//Evitamos el comportamiento por defecto del navegador
    //Si el formulario cumple con todas las validaciones
    if (this.formulario.value.nombre && this.formulario.value.contrasenha && this.formulario.value.rol) {
      //Añadimos el nuevo usuario al array de usuarios
      this.usuarios.push(this.formulario.value);
      //Añadimos el usuario al sessionStorage
      sessionStorage.setItem("usuarios", JSON.stringify(this.usuarios));
      //Limpiamos el formulario
      this.formulario.reset();
    }
  }

  modificarUsuario(usuario: Usuario) {
    //Obtenemos el indice en este caso es el nombre
    const indice = this.usuarios.findIndex(u => u.nombre === usuario.nombre);
    //si es diferente a -1,es decir, si existe
    if (indice !== -1) {
      //Modificamos el usuario
      this.usuarios[indice] = usuario;
      //Guardamos en el sessionStorage
      sessionStorage.setItem("usuarios", JSON.stringify(this.usuarios));
    }
  }

  //Funcion para borrar el usuario
  borrarUsuario(usuario: Usuario) {
    const indice = this.usuarios.findIndex(u => u.nombre === usuario.nombre);
    if (indice !== -1) {
      this.usuarios.splice(indice, 1); // Elimina el usuario en la posición encontrada
    }
  }

  //GETTERS para facilitar el trabajo con los campos del formulario
  get campoNombre() {
    return this.formulario.get('nombre');
  }

  get campoRol() {
    return this.formulario.get('rol');
  }

  get campoContrasenha() {
    return this.formulario.get('contrasenha');
  }

  //Funcion para subscribirse al servicio y obtener a los usuarios
  ngOnInit(): void {
    this.servicioUsuario.subscribirseUsuarios$().subscribe((usuarios) => {
      this.usuarios = usuarios;
    })
  }
}
