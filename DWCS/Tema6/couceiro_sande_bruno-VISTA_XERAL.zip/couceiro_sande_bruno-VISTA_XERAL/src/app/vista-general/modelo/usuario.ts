export interface Usuario {
    nombre:string;
    rol:string;
    contrasenha:string;
}
