export interface Entreno {
    dia:string;
    ejercicio:string;
    repeticiones:string;
}
