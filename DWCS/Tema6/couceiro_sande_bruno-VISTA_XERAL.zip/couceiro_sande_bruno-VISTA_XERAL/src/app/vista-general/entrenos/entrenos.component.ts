import { Component } from '@angular/core';
import { EntrenoManualComponent } from "./entreno-manual/entreno-manual.component";
import { EntrenoIAComponent } from "./entreno-ia/entreno-ia.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-entrenos',
  standalone: true,
  imports: [EntrenoManualComponent, EntrenoIAComponent,CommonModule],
  templateUrl: './entrenos.component.html',
  styleUrl: './entrenos.component.css'
})
export class EntrenosComponent {

  cambiarEntreno:boolean = true;

  cambiarTipoEntreno(){
      this.cambiarEntreno = !this.cambiarEntreno;
  }
}
