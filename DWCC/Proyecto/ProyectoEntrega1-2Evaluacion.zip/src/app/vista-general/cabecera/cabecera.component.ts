import { CommonModule } from '@angular/common';
import { Component, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-cabecera',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cabecera.component.html',
  styleUrl: './cabecera.component.css'
})
export class CabeceraComponent {

  @Output() paginaInicios = new EventEmitter<boolean>();
  @Output() paginaEntrenos = new EventEmitter<boolean>();
  @Output() paginaTienda = new EventEmitter<boolean>();
  @Output() paginaTarifas = new EventEmitter<boolean>();

  cambiarInicio(): void {
    this.paginaInicios.emit(true);
  }
  cambiarEntrenos(): void {
    this.paginaEntrenos.emit(true);
  }
  cambiarTiendas(): void {
    this.paginaTienda.emit(true);
  }
  cambiarTarifas(): void {
    this.paginaTarifas.emit(true);
  }

}
