import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Productos } from '../../productos';
import * as productosDatos from "../../../../public/data/productos.json";

@Component({
  selector: 'app-tienda',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tienda.component.html',
  styleUrl: './tienda.component.css'
})

export class TiendaComponent {

  productos:any = productosDatos;//Array no que almacenaremos o contido do ficheiro JSON
  productoAnhadir:Productos[] = [];//Array no que almacenaremos os productos que se engadiran ao carrito
  mostrarCarro:boolean = false;//Variable que controla se se amosa ou non o carrito

  mostrarCarrito(){
    this.mostrarCarro = !this.mostrarCarro;
  }

  anhadirAlCarro(producto:Productos){
    this.productoAnhadir.push(producto);
    console.log(this.productoAnhadir);
  }

  vaciarCarro(){
    this.productoAnhadir = [];
  }

 /*  //este metodo executase cando a compoñente esta lista para ser cargada na vista
  ngOnInit(): void {
    //Subscribimos a compoñente ao servizo para que o seu array de incidencias estea sempre actualizado
    this.servizo.subscribirse$().subscribe((productos) => {
      this.productos = productos;
      this.cargarTipo();
    })
  }

  //neste metodo recheamos os arrays para diferenciar entre os tipos de productos e colocarlos na sección correspondente
  cargarTipo() {
    this.comidas = this.productos.filter(producto => producto.categoria === 'comida');
    this.accesorios = this.productos.filter(producto => producto.categoria === 'accesorios');
    this.suplementos = this.productos.filter(producto => producto.categoria === 'suplementos');
  }
 */
}
