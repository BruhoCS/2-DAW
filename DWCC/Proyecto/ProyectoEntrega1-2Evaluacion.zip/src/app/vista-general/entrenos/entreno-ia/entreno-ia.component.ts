import { Component } from '@angular/core';

@Component({
  selector: 'app-entreno-ia',
  standalone: true,
  imports: [],
  templateUrl: './entreno-ia.component.html',
  styleUrl: './entreno-ia.component.css'
})
export class EntrenoIAComponent {

}
