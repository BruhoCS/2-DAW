import { Component } from '@angular/core';

@Component({
  selector: 'app-tarifa',
  standalone: true,
  imports: [],
  templateUrl: './tarifa.component.html',
  styleUrl: './tarifa.component.css'
})
export class TarifaComponent {

}
