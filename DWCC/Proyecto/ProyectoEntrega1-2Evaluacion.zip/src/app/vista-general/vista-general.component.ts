import { Component } from '@angular/core';
import { CabeceraComponent } from "./cabecera/cabecera.component";
import { PieComponent } from "./pie/pie.component";
import { CommonModule } from '@angular/common';
import { InicioComponent } from "./inicio/inicio.component";
import { EntrenosComponent } from "./entrenos/entrenos.component";
import { TarifaComponent } from "./tarifa/tarifa.component";
import { TiendaComponent } from "./tienda/tienda.component";

@Component({
  selector: 'app-vista-general',
  standalone: true,
  imports: [CabeceraComponent, CommonModule, InicioComponent, EntrenosComponent, TarifaComponent, TiendaComponent,PieComponent],
  templateUrl: './vista-general.component.html',
  styleUrl: './vista-general.component.css'
})
export class VistaGeneralComponent {
  recibirEntreno: boolean = false;
  recibirTienda: boolean = false;
  recibirTarifas: boolean = false;
  recibirInicio: boolean = true;

  cambiarInicio(pagina: boolean): void {
    this.recibirInicio = pagina;
    this.recibirEntreno = false;
    this.recibirTienda = false;
    this.recibirTarifas = false;
  }
  cambiarEntreno(pagina: boolean): void {
    this.recibirInicio = false;
    this.recibirEntreno = pagina;
    this.recibirTienda = false;
    this.recibirTarifas = false;
  }
  cambiarTienda(pagina: boolean): void {
    this.recibirInicio = false;
    this.recibirEntreno = false;
    this.recibirTienda = pagina;
    this.recibirTarifas = false;
  }
  cambiarTarifas(pagina: boolean): void {
    this.recibirInicio = false;
    this.recibirEntreno = false;
    this.recibirTienda = false;
    this.recibirTarifas = pagina;
  }

}
