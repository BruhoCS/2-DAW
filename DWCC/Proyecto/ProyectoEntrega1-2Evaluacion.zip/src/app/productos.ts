export interface Productos{
    nombre: string;
    imagen:string;
    categoria:string;
    precio:number;  
}
